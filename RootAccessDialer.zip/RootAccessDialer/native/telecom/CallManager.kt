package com.rootaccess.dialer

import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import java.util.concurrent.CopyOnWriteArrayList

data class CallSnapshot(
    val state: String,
    val displayName: String,
    val isPrivate: Boolean,
    val incoming: Boolean,
    val connectTimeMillis: Long,
    val muted: Boolean,
    val speaker: Boolean
)

internal object CallManager {
    private var service: InCallService? = null
    private val calls = mutableListOf<Call>()
    private val incomingCalls = mutableSetOf<Call>()
    private val listeners = CopyOnWriteArrayList<(CallSnapshot) -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = publish()
        override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
    }

    fun addListener(l: (CallSnapshot) -> Unit) { listeners.add(l) }
    fun removeListener(l: (CallSnapshot) -> Unit) { listeners.remove(l) }

    fun onCallAdded(call: Call, svc: InCallService) {
        service = svc
        if (call.state == Call.STATE_RINGING) incomingCalls.add(call)
        calls.add(call)
        call.registerCallback(callback)
        publish()
    }

    fun onCallRemoved(call: Call) {
        call.unregisterCallback(callback)
        calls.remove(call)
        incomingCalls.remove(call)
        publish()
    }

    private fun primary(): Call? =
        calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.lastOrNull()

    fun snapshot(): CallSnapshot {
        val call = primary() ?: return CallSnapshot("idle", "", false, false, 0L, false, false)
        val number = call.details?.handle?.schemeSpecificPart
        val priv = PrivateIdentity.isPrivate(number)
        val name = if (priv) PrivateIdentity.DISPLAY_NAME
        else call.details?.callerDisplayName?.takeIf { it.isNotBlank() } ?: number ?: "Unknown"
        val state = when (call.state) {
            Call.STATE_RINGING -> "ringing"
            Call.STATE_ACTIVE -> "active"
            Call.STATE_HOLDING -> "holding"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "disconnected"
            else -> "dialing"
        }
        @Suppress("DEPRECATION")
        val audio = service?.callAudioState
        return CallSnapshot(
            state, name, priv, incomingCalls.contains(call),
            call.details?.connectTimeMillis ?: 0L,
            audio?.isMuted ?: false,
            audio?.route == CallAudioState.ROUTE_SPEAKER
        )
    }

    fun publish() {
        val s = snapshot()
        listeners.forEach { it(s) }
    }

    fun answer() { primary()?.answer(VideoProfile.STATE_AUDIO_ONLY) }
    fun reject() { primary()?.reject(false, null) }
    fun hangup() { primary()?.disconnect() }
    fun setMuted(m: Boolean) { service?.setMuted(m) }
    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE)
    }

    fun dtmf(c: Char) {
        val call = primary() ?: return
        call.playDtmfTone(c)
        main.postDelayed({ call.stopDtmfTone() }, 120)
    }
}
