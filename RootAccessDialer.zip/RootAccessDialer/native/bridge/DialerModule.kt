package com.rootaccess.dialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.telecom.TelecomManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule

class DialerModule(private val ctx: ReactApplicationContext) : ReactContextBaseJavaModule(ctx) {

    override fun getName() = "Dialer"

    private val listener: (CallSnapshot) -> Unit = { emit(it) }

    override fun initialize() {
        super.initialize()
        CallManager.addListener(listener)
    }

    override fun invalidate() {
        CallManager.removeListener(listener)
        super.invalidate()
    }

    private fun CallSnapshot.toMap(): WritableMap = Arguments.createMap().apply {
        putString("state", state)
        putString("displayName", displayName)
        putBoolean("isPrivate", isPrivate)
        putBoolean("incoming", incoming)
        putDouble("connectTime", connectTimeMillis.toDouble())
        putBoolean("muted", muted)
        putBoolean("speaker", speaker)
    }

    private fun emit(s: CallSnapshot) {
        if (!ctx.hasActiveReactInstance()) return
        ctx.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit("onCallState", s.toMap())
    }

    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}

    @ReactMethod
    fun getCurrentCall(promise: Promise) = promise.resolve(CallManager.snapshot().toMap())

    private fun place(uri: Uri, promise: Promise) {
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            promise.reject("E_PERMISSION", "Phone permission required")
            return
        }
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.placeCall(uri, Bundle())
            promise.resolve(true)
        } catch (e: SecurityException) {
            promise.reject("E_PERMISSION", "Phone permission required")
        } catch (e: Exception) {
            promise.reject("E_CALL", "Unable to place call")
        }
    }

    @ReactMethod
    fun callPrivate(promise: Promise) = place(PrivateIdentity.dialUri(), promise)

    @ReactMethod
    fun dial(digits: String, promise: Promise) {
        if (digits.isBlank()) { promise.reject("E_EMPTY", "Nothing to dial"); return }
        if (PrivateIdentity.isPrivate(digits)) place(PrivateIdentity.dialUri(), promise)
        else place(Uri.fromParts("tel", digits, null), promise)
    }

    /** Returns the display name if the typed digits match the private contact, else null. */
    @ReactMethod
    fun resolveInput(digits: String, promise: Promise) = promise.resolve(PrivateIdentity.resolve(digits))

    @ReactMethod fun answer() = CallManager.answer()
    @ReactMethod fun reject() = CallManager.reject()
    @ReactMethod fun hangup() = CallManager.hangup()
    @ReactMethod fun setMuted(muted: Boolean) = CallManager.setMuted(muted)
    @ReactMethod fun setSpeaker(on: Boolean) = CallManager.setSpeaker(on)
    @ReactMethod fun sendDtmf(d: String) { if (d.isNotEmpty()) CallManager.dtmf(d[0]) }

    @ReactMethod
    fun isDefaultDialer(promise: Promise) {
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        promise.resolve(tm.defaultDialerPackage == ctx.packageName)
    }

    @ReactMethod
    fun requestDefaultDialer(promise: Promise) {
        val act = currentActivity ?: run { promise.reject("E_ACTIVITY", "No activity"); return }
        try {
            val intent: Intent = if (Build.VERSION.SDK_INT >= 29) {
                val rm = ctx.getSystemService(Context.ROLE_SERVICE) as RoleManager
                rm.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            } else {
                Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, ctx.packageName)
            }
            act.startActivityForResult(intent, 4242)
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("E_ROLE", "Unable to request default dialer role")
        }
    }

    /** Reads the system call log; private-contact rows are masked here and never expose the number. */
    @ReactMethod
    fun getCallLog(limit: Int, promise: Promise) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            promise.reject("E_PERMISSION", "Call log permission required")
            return
        }
        Thread {
            try {
                val out = Arguments.createArray()
                val proj = arrayOf(
                    CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.TYPE,
                    CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.CACHED_NAME
                )
                ctx.contentResolver.query(
                    CallLog.Calls.CONTENT_URI, proj, null, null, "${CallLog.Calls.DATE} DESC"
                )?.use { c ->
                    var n = 0
                    while (c.moveToNext() && n < limit) {
                        val type = when (c.getInt(2)) {
                            CallLog.Calls.INCOMING_TYPE -> "incoming"
                            CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                            CallLog.Calls.MISSED_TYPE -> "missed"
                            CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> "rejected"
                            else -> continue
                        }
                        val number = c.getString(1)
                        val priv = PrivateIdentity.isPrivate(number)
                        val map = Arguments.createMap()
                        map.putString("id", c.getLong(0).toString())
                        map.putString("type", type)
                        map.putBoolean("isPrivate", priv)
                        map.putString(
                            "name",
                            if (priv) PrivateIdentity.DISPLAY_NAME
                            else c.getString(5)?.takeIf { it.isNotBlank() } ?: number ?: "Unknown"
                        )
                        map.putString("number", if (priv) "" else number ?: "")
                        map.putDouble("date", c.getLong(3).toDouble())
                        map.putInt("duration", c.getInt(4))
                        out.pushMap(map)
                        n++
                    }
                }
                promise.resolve(out)
            } catch (e: Exception) {
                promise.reject("E_LOG", "Unable to read call log")
            }
        }.start()
    }

    /** Requests the highest refresh rate the panel supports at the current resolution. */
    @ReactMethod
    fun setHighRefreshRate(promise: Promise) {
        val act = currentActivity ?: run { promise.resolve(0.0); return }
        act.runOnUiThread {
            try {
                @Suppress("DEPRECATION")
                val display = act.windowManager.defaultDisplay
                val cur = display.mode
                val best = display.supportedModes
                    .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                    .maxByOrNull { it.refreshRate } ?: cur
                val lp = act.window.attributes
                lp.preferredDisplayModeId = best.modeId
                act.window.attributes = lp
                promise.resolve(best.refreshRate.toDouble())
            } catch (e: Exception) {
                promise.resolve(0.0)
            }
        }
    }
}
