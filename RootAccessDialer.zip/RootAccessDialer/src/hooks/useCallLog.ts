import { useCallback, useEffect, useState } from 'react';
import { CALL_LOG_LIMIT } from '../constants';
import { Dialer, callEvents } from '../services/dialer';
import type { CallInfo, CallLogEntry } from '../types';

export function useCallLog() {
  const [items, setItems] = useState<CallLogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      setItems(await Dialer.getCallLog(CALL_LOG_LIMIT));
      setError(null);
    } catch {
      setError('Allow call log access to see your history.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    let t: ReturnType<typeof setTimeout> | undefined;
    const sub = callEvents.addListener('onCallState', (c: CallInfo) => {
      if (c.state === 'idle') {
        if (t) clearTimeout(t);
        t = setTimeout(refresh, 700); // the system log is written slightly after the call ends
      }
    });
    return () => { sub.remove(); if (t) clearTimeout(t); };
  }, [refresh]);

  return { items, error, loading, refresh };
}
