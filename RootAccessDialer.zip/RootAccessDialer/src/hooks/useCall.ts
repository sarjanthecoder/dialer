import { useEffect, useState } from 'react';
import { Dialer, callEvents } from '../services/dialer';
import type { CallInfo } from '../types';

const IDLE: CallInfo = {
  state: 'idle', displayName: '', isPrivate: false, incoming: false, connectTime: 0, muted: false, speaker: false,
};

export function useCall(): CallInfo {
  const [call, setCall] = useState<CallInfo>(IDLE);
  useEffect(() => {
    Dialer.getCurrentCall().then(setCall).catch(() => {});
    const sub = callEvents.addListener('onCallState', (c: CallInfo) => setCall(c));
    return () => sub.remove();
  }, []);
  return call;
}
