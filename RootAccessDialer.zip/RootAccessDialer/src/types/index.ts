export type CallStateName = 'idle' | 'ringing' | 'dialing' | 'active' | 'holding' | 'disconnected';

export interface CallInfo {
  state: CallStateName;
  displayName: string;
  isPrivate: boolean;
  incoming: boolean;
  connectTime: number;
  muted: boolean;
  speaker: boolean;
}

export type CallLogType = 'incoming' | 'outgoing' | 'missed' | 'rejected';

export interface CallLogEntry {
  id: string;
  type: CallLogType;
  name: string;
  isPrivate: boolean;
  number: string; // empty for the private contact
  date: number;
  duration: number;
}

export type TabKey = 'dialer' | 'private' | 'history';
