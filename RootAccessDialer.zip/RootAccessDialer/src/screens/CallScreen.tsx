import React, { memo, useCallback, useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  Easing, FadeIn, FadeOut, cancelAnimation, interpolate, useAnimatedStyle, useSharedValue, withRepeat, withTiming,
} from 'react-native-reanimated';
import { Avatar } from '../components/Avatar';
import { Keypad } from '../components/Keypad';
import { RoundAction } from '../components/RoundAction';
import { Dialer } from '../services/dialer';
import { colors, fonts } from '../theme';
import type { CallInfo } from '../types';
import { formatDuration } from '../utils/format';

const Pulse = memo(function Pulse({ running }: { running: boolean }) {
  const s = useSharedValue(1);
  useEffect(() => {
    if (running) s.value = withRepeat(withTiming(1.4, { duration: 1400, easing: Easing.out(Easing.quad) }), -1, false);
    else { cancelAnimation(s); s.value = withTiming(1, { duration: 200 }); }
  }, [running, s]);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: s.value }], opacity: interpolate(s.value, [1, 1.4], [running ? 0.5 : 0, 0]) }));
  return <Animated.View pointerEvents="none" style={[styles.ring, style]} />;
});

// Real duration: derived from the telecom stack's connect timestamp, not a fake counter.
const CallTimer = memo(function CallTimer({ since }: { since: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id); }, []);
  const secs = since > 0 ? Math.max(0, Math.floor((now - since) / 1000)) : 0;
  return <Text style={styles.status}>{formatDuration(secs)}</Text>;
});

const Dots = memo(function Dots({ base }: { base: string }) {
  const [n, setN] = useState(0);
  useEffect(() => { const id = setInterval(() => setN((v) => (v + 1) % 4), 450); return () => clearInterval(id); }, []);
  return <Text style={styles.status}>{base}{'.'.repeat(n)}</Text>;
});

export function CallScreen({ call }: { call: CallInfo }) {
  const [showPad, setShowPad] = useState(false);
  const [typed, setTyped] = useState('');

  useEffect(() => { if (call.state === 'idle') { setShowPad(false); setTyped(''); } }, [call.state]);

  const answer = useCallback(() => Dialer.answer(), []);
  const reject = useCallback(() => Dialer.reject(), []);
  const hangup = useCallback(() => Dialer.hangup(), []);
  const toggleMute = useCallback(() => Dialer.setMuted(!call.muted), [call.muted]);
  const toggleSpeaker = useCallback(() => Dialer.setSpeaker(!call.speaker), [call.speaker]);
  const togglePad = useCallback(() => setShowPad((v) => !v), []);
  const dtmf = useCallback((d: string) => { Dialer.sendDtmf(d); setTyped((t) => (t + d).slice(-18)); }, []);

  const ringing = call.state === 'ringing';
  const pulsing = ringing || call.state === 'dialing';

  let status: React.ReactNode;
  if (ringing) status = <Text style={styles.status}>Incoming call</Text>;
  else if (call.state === 'dialing') status = <Dots base="Calling" />;
  else if (call.state === 'active') status = <CallTimer since={call.connectTime} />;
  else if (call.state === 'holding') status = <Text style={styles.status}>On hold</Text>;
  else status = <Text style={styles.status}>Call ended</Text>;

  return (
    <Animated.View entering={FadeIn.duration(220)} exiting={FadeOut.duration(180)} style={styles.overlay}>
      <LinearGradient colors={['#0B1530', '#050507', '#050507']} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={styles.safe}>
        <View style={styles.top}>
          <View style={styles.avatarWrap}>
            <Pulse running={pulsing} />
            <Avatar size={120} />
          </View>
          <Text style={styles.name} numberOfLines={2}>{call.displayName}</Text>
          {status}
        </View>

        {showPad && call.state !== 'ringing' ? (
          <View style={styles.padWrap}>
            <Text style={styles.typed} numberOfLines={1}>{typed}</Text>
            <Keypad onPress={dtmf} />
          </View>
        ) : null}

        {ringing ? (
          <View style={styles.rowBetween}>
            <RoundAction icon="call" size={78} bg={colors.red} iconColor="#fff" rotate={135} label="Decline" onPress={reject} />
            <RoundAction icon="call" size={78} bg={colors.green} iconColor="#04130A" label="Accept" onPress={answer} />
          </View>
        ) : (
          <View style={styles.controls}>
            <View style={styles.rowBetween}>
              <RoundAction icon={call.muted ? 'mic-off' : 'mic'} bg={call.muted ? colors.text : colors.surfaceStrong} iconColor={call.muted ? '#000' : colors.text} label="Mute" onPress={toggleMute} />
              <RoundAction icon="keypad" bg={showPad ? colors.text : colors.surfaceStrong} iconColor={showPad ? '#000' : colors.text} label="Keypad" onPress={togglePad} />
              <RoundAction icon="volume-high" bg={call.speaker ? colors.text : colors.surfaceStrong} iconColor={call.speaker ? '#000' : colors.text} label="Speaker" onPress={toggleSpeaker} />
            </View>
            <RoundAction icon="call" size={78} bg={colors.red} iconColor="#fff" rotate={135} onPress={hangup} />
          </View>
        )}
      </SafeAreaView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.bg, zIndex: 100 },
  safe: { flex: 1, justifyContent: 'space-between', paddingHorizontal: 32, paddingBottom: 32 },
  top: { alignItems: 'center', paddingTop: 48 },
  avatarWrap: { width: 120, height: 120, alignItems: 'center', justifyContent: 'center' },
  ring: { position: 'absolute', width: 120, height: 120, borderRadius: 60, borderWidth: 2, borderColor: colors.accent },
  name: { color: colors.text, fontFamily: fonts.semibold, fontSize: 28, marginTop: 28, textAlign: 'center' },
  status: { color: colors.textDim, fontFamily: fonts.medium, fontSize: 16, marginTop: 10, minHeight: 22 },
  padWrap: { alignItems: 'center', gap: 14 },
  typed: { color: colors.text, fontFamily: fonts.medium, fontSize: 24, minHeight: 32 },
  controls: { alignItems: 'center', gap: 36 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-around', alignSelf: 'stretch' },
});
