import React, { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme';

export const Avatar = memo(function Avatar({ size = 96 }: { size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, overflow: 'hidden', borderWidth: 1, borderColor: colors.accentSoft }}>
      <LinearGradient colors={['#1B2B4D', '#0A0F1E']} style={styles.fill}>
        <Text style={{ fontSize: size * 0.42 }}>💫</Text>
      </LinearGradient>
    </View>
  );
});

const styles = StyleSheet.create({ fill: { flex: 1, alignItems: 'center', justifyContent: 'center' } });
