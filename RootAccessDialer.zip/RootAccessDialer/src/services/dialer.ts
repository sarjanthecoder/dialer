import { NativeEventEmitter, NativeModules, PermissionsAndroid, Platform } from 'react-native';
import type { Permission } from 'react-native';
import type { CallInfo, CallLogEntry } from '../types';

interface DialerNative {
  getCurrentCall(): Promise<CallInfo>;
  callPrivate(): Promise<boolean>;
  dial(digits: string): Promise<boolean>;
  resolveInput(digits: string): Promise<string | null>;
  answer(): void;
  reject(): void;
  hangup(): void;
  setMuted(muted: boolean): void;
  setSpeaker(on: boolean): void;
  sendDtmf(digit: string): void;
  isDefaultDialer(): Promise<boolean>;
  requestDefaultDialer(): Promise<boolean>;
  getCallLog(limit: number): Promise<CallLogEntry[]>;
  setHighRefreshRate(): Promise<number>;
}

export const Dialer = NativeModules.Dialer as DialerNative;
export const callEvents = new NativeEventEmitter(NativeModules.Dialer);

export async function requestRuntimePermissions(): Promise<boolean> {
  if (Platform.OS !== 'android') return false;
  const P = PermissionsAndroid.PERMISSIONS;
  const list: Permission[] = [P.CALL_PHONE, P.READ_PHONE_STATE, P.READ_CALL_LOG, P.ANSWER_PHONE_CALLS];
  if (Number(Platform.Version) >= 33) list.push(P.POST_NOTIFICATIONS);
  const res = await PermissionsAndroid.requestMultiple(list);
  return res[P.CALL_PHONE] === PermissionsAndroid.RESULTS.GRANTED;
}
