import React, { useEffect } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFonts, Inter_400Regular, Inter_500Medium, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { AppNavigator } from './src/navigation/AppNavigator';
import { CallScreen } from './src/screens/CallScreen';
import { useCall } from './src/hooks/useCall';
import { Dialer, requestRuntimePermissions } from './src/services/dialer';
import { colors } from './src/theme';

export default function App() {
  const [fontsLoaded] = useFonts({ Inter_400Regular, Inter_500Medium, Inter_600SemiBold });
  const call = useCall();

  useEffect(() => {
    Dialer.setHighRefreshRate().catch(() => {});
    requestRuntimePermissions().catch(() => {});
  }, []);

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: colors.bg }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <AppNavigator />
        {call.state !== 'idle' && <CallScreen call={call} />}
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
